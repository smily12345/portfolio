import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Github, Linkedin } from "lucide-react";

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 p-6 font-sans">
      <header className="text-center py-10">
        <img
          src="/image-1.jpg"
          alt="Gola Swapna"
          className="mx-auto rounded-full w-40 h-40 object-cover border-4 border-white shadow-md mb-4"
        />
        <h1 className="text-4xl font-bold mb-2">Gola Swapna</h1>
        <p className="text-lg text-gray-600">Aspiring Web & App Developer | B.Tech CSE @ G. Pulayya College of Engineering and Technology</p>
      </header>

      <section className="max-w-4xl mx-auto grid gap-8">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-2">About Me</h2>
            <p>
              I’m a passionate first-year Computer Science student with a strong interest in web and app development. My mission is to build impactful solutions through technology and continuously grow as a developer.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-2">Skills</h2>
            <ul className="list-disc list-inside">
              <li>HTML</li>
              <li>Python</li>
              <li>C Programming</li>
              <li>Basics of AI Tools</li>
              <li>Problem Solving (DSA - Learning Stage)</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-2">Projects</h2>
            <ul className="list-disc list-inside">
              <li>
                <strong>Quiz Game in C:</strong> Developed a CLI-based quiz application in C using basic control structures.
              </li>
              <li>
                <strong>AI Agent:</strong> Successfully created and executed a simple AI agent demonstrating decision-making capabilities.
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-2">Workshops & Events</h2>
            <ul className="list-disc list-inside">
              <li>Symbiotes AI Workshop</li>
              <li>Mastermind Program - Vibe by CICINTI</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <h2 className="text-2xl font-semibold mb-2">Contact Me</h2>
            <div className="flex justify-center gap-4 mt-4">
              <Button variant="outline" asChild>
                <a href="https://github.com/smily12345" target="_blank" rel="noopener noreferrer">
                  <Github className="w-5 h-5 mr-2" /> GitHub
                </a>
              </Button>
              <Button variant="outline" asChild>
                <a href="https://www.linkedin.com/in/golla-g-swapna-46525a329" target="_blank" rel="noopener noreferrer">
                  <Linkedin className="w-5 h-5 mr-2" /> LinkedIn
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
