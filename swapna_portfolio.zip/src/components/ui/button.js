
export function Button({ children, asChild, variant }) { return <button className="border rounded p-2">{children}</button>; }
