
export function Github(props) { return <svg {...props}><circle cx="12" cy="12" r="10"/></svg>; }
export function Linkedin(props) { return <svg {...props}><rect x="4" y="4" width="16" height="16"/></svg>; }
